English:
========
The functionality of a CANopen module is described with a so called 
EDS File (Electronic Data Sheet). These contain the entries of the CANopen
object dictionary supported by that module.

The EDS files are available in two formats:
- The older d *.eds format according to CiA 306 
- The newer XML based *.xdd format according to ISO 15745-2. 

At https://www.vector.com/canopen_caneds_de.html you can find a free tool 
to display and edit eds/xdd files in a clear and understandable way.

For CANopen configuration tools like Vectors ProCANopen or CANsetter an 
additional image file in *.bmp format is provided which serves as an icon for
a module.
