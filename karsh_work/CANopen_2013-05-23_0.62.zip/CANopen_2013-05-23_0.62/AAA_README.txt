The files in this folder contain data for SCHUNK CANopen mechatronics modules

- *.flash
  Module specific CANopen firmware flash files for the following module types:
  - PRL+
  - ERB 
  - PG70+

- ElectronicDataSheet directory:
  - README.txt further explanation on EDS/XDD files in English
  - LIESMICH.txt further explanation on EDS/XDD files in German
  - *.xdd
    CANopen electronic data sheet in new XML-based XDD format

  - *.eds
    CANopen electronic data sheet in old ini-style EDS format

  - *.bmp
    Module icons used by some 3rd party CANopen configuration tools (e.g. 
    vector informatics)


The firmware of a module can be updated using the Motion Tool SCHUNK MTS.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
WARNING: You _MUST_ use a MTS version of at least 1.5.6.7. Older versions may
         corrupt configuration parameters of the module on update! The module
         will then report "ERROR_CURRENT" right from the start. 
         In such cases please contact the SCHUNK service.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

An appropriate MTS version can be downloaded here:
https://dl.dropbox.com/u/4896179/SCHUNK/dist/MTS-1.5.6.7.zip
