/*
 * pdo.cpp
 *
 * Simple CANopen PDO (Process Data Object) implementation.
 * (Unused since all is done in the header file for now)
 *
 *  Created on: 13.02.2012
 *      Author: osswald2
 */

#include <assert.h>

#include "pdo.h"

