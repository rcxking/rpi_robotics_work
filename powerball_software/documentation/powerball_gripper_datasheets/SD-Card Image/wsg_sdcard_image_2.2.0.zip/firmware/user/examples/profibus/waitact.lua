-- Wait for Activity on IF1:
activity, state = profibus.waitact( 0x01 );
if activity ~= 0 then
	printf( "Activity detected!\n" );
	if state > 0 then 
		printf( "Raising edge\n" ); 
	else printf( "Falling edge\n" ); 
end;
