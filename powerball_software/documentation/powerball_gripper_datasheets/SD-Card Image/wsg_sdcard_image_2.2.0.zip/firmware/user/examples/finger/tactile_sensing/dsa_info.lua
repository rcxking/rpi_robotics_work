if ( dsa.present( 0 )) then
    cfg = dsa.info( 0 );
    printf( "Controller type is %s\n", cfg.type );
    printf( "Matrix has %dx%d sensor cells\n", cfg.cells_x, cfg.cells_y );
else
    printf( "No tactile sensor found at Finger 0\n" );
end;
   
   
