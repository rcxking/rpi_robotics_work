if mc.overdrive() then 
    printf( "Overdrive mode is enabled\n" );
else
    printf( "Overdrive mode is disabled and will be enabled, now.\n" );
    mc.overdrive( true );  -- enable overdrive mode
end;
force, limit = mc.force( 100 );  -- Set the force limit to 100N

printf( "Current force limit is set to %.2fN\n", limit );
sleep( 3000 );
