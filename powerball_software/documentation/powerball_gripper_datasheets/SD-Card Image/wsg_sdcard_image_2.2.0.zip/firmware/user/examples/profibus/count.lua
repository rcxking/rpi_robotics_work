-- Simple counter example. The counting value is written to the Profibus Output Flags (OF)
count = 0;
while profibus.online() do
	count = count + 1;
	if count == 256 then
		count = 1;
	end;
	profibus.flags( count );  -- write counting value to the Profibus Output Flags
	sleep( 500 );
end;
