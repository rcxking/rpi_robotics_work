-- Movement speed is determined by the state of Input Flag 1
-- State of Output Flags 1 and 2 are toggled according to the position reached
POS_A = 10;
POS_B = 60;
position = POS_A;

profibus.fclear( 0xFF ); -- reset Output User Flags 
while profibus.online() do

    -- Determine speed from the state of Input User Flag 1:
    if profibus.flag( 1 ) == 0 then
        speed = 50.0;
    else
        speed = 10.0;
    end;
    -- move and wait while busy:
    mc.move( position, speed, 1 );
    
    -- Toggle target position:
    if position == POS_A then
        profibus.flag( 1, 0 );
        profibus.flag( 2, 1 ); -- set Output User Flag 2 as ack to the PLC
        position = POS_B;
    else
        profibus.flag( 1, 1 ); -- set Output User Flag 1 as ack to the PLC
        profibus.flag( 2, 0 );
        position = POS_A;
    end;
end;
