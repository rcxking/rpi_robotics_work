if finger.type( 1 ) == FT_GENERIC then
    while true do
        sleep( 1000 );
        rxdata = finger.spi( 1, 0x1234 ); -- SPI transfer with finger 0
        for i=1,#rxdata do  -- print out the received data
           printf( "%.4Xh ", rxdata[i] );
        end;   
        printf( "\n" );
    end;
else
    printf( "Cannot read data from a non-generic finger.\n" );
end;
