These are simple tests for Lua.  Some of them contain useful code.
They are meant to be run to make sure Lua is built correctly and also
to be read, to see how Lua programs look.

Here is a one-line summary of each program:

   bisect.lua         bisection method for solving non-linear equations
   cf.lua             temperature conversion table (celsius to farenheit)
   echo.lua           echo command line arguments
   factorial.lua      factorial without recursion
   fib.lua            fibonacci function with cache
   hello.lua          the first program in every language
   life.lua           Conway's Game of Life
   printf.lua         an implementation of printf
   readonly.lua       make global variables readonly
   sort.lua           two implementations of a sort function
   trace-globals.lua  trace assigments to global variables

