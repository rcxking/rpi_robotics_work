id = 0xBB;
cmd.register( id );    -- Register ID BBh
if cmd.online() then
-- String payload:
cmd.send( id, "This is a test!" );
-- Number as payload:
cmd.send( id, ntob( 1.234 ));
-- Payload combining various types:
cmd.send( id, 0x54, 0x68, "is is a test!", {1, 2, 3}, {4, 5, ntob(6.7), { "Nested Table" }} );
-- Payload with nested tables:
cmd.send( id, { 1, 2, { 3, 4, { 5, 6, { 7, 8, { 9, 10 }}}}} );
else
    printf( "Sorry, currently offline!\n" );
end;


