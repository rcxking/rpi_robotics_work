$(document).ready(function(){module("webcon");test("some test",function(){})});
