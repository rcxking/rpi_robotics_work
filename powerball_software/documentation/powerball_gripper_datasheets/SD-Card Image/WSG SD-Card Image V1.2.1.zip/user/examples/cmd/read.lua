-- This example implements a custom command (ID=0xBB) to set the GPIO’s output pins
cmd.register( 0xBB );    -- Register ID BBh
while true do
    if cmd.online() then
        id, payload = cmd.read();
        if #payload == 1 then
            -- Payload length is okay:
            printf( "Setting outputs to %d\n", payload[1] );
            gpio.pins( payload[1] );
            cmd.send( id, etob( E_SUCCESS )); -- Send E_SUCCESS as return value
        else
            -- Error: Payload length mismatch:
            printf( "Payload length mismatch (%d)\n", #payload );
            cmd.send( id, 15, etob( E_CMD_FORMAT_ERROR )); -- Send E_CMD_FORMAT_ERROR as return value
        end;
    else
        -- Interface is offline...
        sleep( 50 );
    end;
end;

