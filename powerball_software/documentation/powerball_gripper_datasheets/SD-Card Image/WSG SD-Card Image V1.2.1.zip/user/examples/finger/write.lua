if finger.type( 0 ) == FT_GENERIC then
    for i=1,10 do
        finger.write( 0, "Hello Finger, this is a test: "..tostring(i).."\n" );
    end;
else
    printf( "Cannot send data to a non-generic finger.\n" );
end;

