print( "Hello!" );  
while ( gpio.pin(1) == 1 ) do
  gpio.clear(1);
  gpio.set(2);
  if ( gpio.pin(0) == 0 ) then sleep( 100 );
    else sleep( 500 );
  end;
  gpio.clear(2);
  gpio.set(1);
  if ( gpio.pin(0) == 0 ) then sleep( 100 );
    else sleep( 500 );
  end;
end;
gpio.clear(3);
print( "Bye!" ); 