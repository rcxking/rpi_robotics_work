while true do
    printf( "Analog input: %.2fV\n", finger.analog( 0 )); -- Get the analog input voltage of finger 0
    sleep( 500 );
end;

