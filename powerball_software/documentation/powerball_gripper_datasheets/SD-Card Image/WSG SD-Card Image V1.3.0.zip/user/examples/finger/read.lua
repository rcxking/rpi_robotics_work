index = 0;
if finger.type( index ) == FT_GENERIC then
    while true do
        data = finger.read( index );
        if #data > 0 then 
            for i=1,#data do
                printf( "%c", data[i] );
            end;
        end;   
    end;
else
    printf( "Cannot read data from a non-generic finger.\n" );
end;

