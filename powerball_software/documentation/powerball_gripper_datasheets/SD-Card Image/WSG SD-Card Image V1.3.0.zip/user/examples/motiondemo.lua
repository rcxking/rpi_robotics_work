SIM = 0;

if ( SIM == 1 ) then
  function sleep( ms )
    printf( "Sleeping for %d ms\n", ms );
  end;

  mc = {};

  mc.move = function( pos, speed )
    printf( "Going to %g, speed: %g\n", pos, speed );
  end;

  mc.acceleration = function( acceleration )
    printf( "Setting acceleration to %g\n", acceleration );
  end;

  mc.force_limit = function( force )
    printf( "Setting force limit to %g\n", force );
  end;

  mc.homing = function()
    printf( "Executing homing sequence\n" );
  end;
end;

-- Movement sequence:

SLOW_ACC = 200;
FAST_ACC = 4000;
FORCE = 35;

seq = {
  { speed=  10.0, pos= 109.5, acc= FAST_ACC, delay=  500 },
  { speed=  50.0, pos=  75.0, acc= FAST_ACC, delay=  300 },
  { speed= 100.0, pos=  50.0, acc= FAST_ACC, delay=  300 },
  { speed= 150.0, pos=  25.0, acc= FAST_ACC, delay=  300 },
  { speed= 200.0, pos=   6.5, acc= FAST_ACC, delay= 1000 },
  { speed= 300.0, pos= 109.5, acc= FAST_ACC, delay=  500 },
  { speed= 420.0, pos=  75.0, acc= FAST_ACC, delay=  300 },
  { speed= 420.0, pos=  50.0, acc= FAST_ACC, delay=  300 },
  { speed= 420.0, pos=  25.0, acc= FAST_ACC, delay=  300 },
  { speed= 420.0, pos=   6.5, acc= FAST_ACC, delay= 1000 },
  { speed= 420.0, pos= 109.5, acc= SLOW_ACC, delay=  500 },
  { speed= 420.0, pos=   6.5, acc= SLOW_ACC, delay=  500 },
  { speed= 420.0, pos= 109.5, acc= FAST_ACC, delay=  500 },
  { speed= 420.0, pos=   6.5, acc= FAST_ACC, delay=  500 },
};


-------------------------
--- MAIN DEMO PROGRAM ---
-------------------------

-- Do homing:
mc.homing(1);

-- Set force:
mc.force( FORCE );

-- Set initial acceleration:
current_acc = SLOW_ACC;
mc.acceleration( current_acc );

-- Looping through the sequence:
while ( true ) do

  for i=1,#seq do

    -- Set acceleration:
    if ( current_acc ~= seq[i].acc ) then
      current_acc = seq[i].acc;
      mc.acceleration( current_acc );
    end;

    -- Wait for last movement to be finished:
    while ( mc.busy() ) do
      sleep( 100 );
    end;
        
    -- Goto new position:
    mc.move( seq[i].pos, seq[i].speed );

    -- Sleep, if required:
  if ( seq[i].delay > 0 ) then
      sleep( seq[i].delay );
    end;
  end;
end;
