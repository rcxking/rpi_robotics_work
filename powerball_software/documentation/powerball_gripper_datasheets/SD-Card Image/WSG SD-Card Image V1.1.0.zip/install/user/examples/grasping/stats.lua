-- do some grasping...
for i=1,10 do
    grasping.grasp();
    sleep( 500 );
    grasping.release( 20 );
end;
-- get grasping statistics:
tg, np, lp = grasping.stats();
printf( "Current grasping statistics:\n" );
printf( "\tTotal grasps: %d\n", tg );
printf( "\tNo part found: %d\n", np );
printf( "\tLost parts: %d\n", lp );

