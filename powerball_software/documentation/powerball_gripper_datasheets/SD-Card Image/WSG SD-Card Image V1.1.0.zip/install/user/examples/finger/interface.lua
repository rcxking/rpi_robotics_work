for i=0,finger.count()-1 do
    printf( "Finger %d interface: %s\n", i, finger.interface( i ));    
end;
