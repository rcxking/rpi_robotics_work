-- Constants:
OPEN_POSITION = 70;
CLOSE_POSITION = 10;
SPEED = 300;

state = 0;
mc.homing();
mc.force( 50 );

while ( true ) do
    
    -- get IO-State:
    last_state = state;
    state = gpio.pin(0);
    
	-- detect a state change:
    if ( state ~= last_state ) then
        if ( state == 1 ) then
            
            -- Close Fingers:
            gpio.set( 1 );
            mc.goto( CLOSE_POSITION, SPEED );
        else
            -- Open Fingers:
            gpio.clear( 1 );
            mc.goto( OPEN_POSITION, SPEED );
        end;
    end;
end;
        
