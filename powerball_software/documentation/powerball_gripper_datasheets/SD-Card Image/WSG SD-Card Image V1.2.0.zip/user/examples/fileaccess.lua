-- File Access demo:
f = assert( io.open("examples/text.txt", "r" ));
text = f:read( "*all" );
f:close();
print( text );

