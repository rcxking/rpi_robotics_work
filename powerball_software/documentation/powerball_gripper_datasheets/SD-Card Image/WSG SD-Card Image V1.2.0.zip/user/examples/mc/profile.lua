profilenames = { "sin2x", "ramp", "rectangular" };
mc.acceleration( 100 ); -- setting acceleration to 100 mm/s²
mc.force( 50 ); -- setting force limit to 50 N
mc.move( 10, 50 ); -- Move to 10mm, speed=50mm/s, wait, until target position was reached.
for profile=0,2 do 
    printf( "Setting %s profile\n", profilenames[ profile + 1 ]);
    mc.profile( profile );
    mc.move( 100, 50 ); 
    sleep( 1000 );
    mc.move( 10, 50 );
    sleep( 1000 );
end;
