state = grasping.state();
if state == 4 then
    printf( "Holding a part\n" );
else
    printf( "No part!\n" );
end;

grasping.grasp( 10 );
printf( "Current grasping state is '%s'\n", grasping.statestring() );
