mc.softlimits_en( false );
if not mc.softlimits_en() then
    -- Currently no soft limits set, so we do it, now:
    printf( " Setting negative limit: %.1f mm, Positive limit: %.1f mm\n", mc.softlimits( 10, 90 ));
end;
