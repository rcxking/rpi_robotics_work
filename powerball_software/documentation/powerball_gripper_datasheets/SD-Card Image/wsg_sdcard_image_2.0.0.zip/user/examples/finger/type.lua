for i=0,finger.count()-1 do
    if finger.type(i) == FT_GENERIC then
        printf( "Finger %d is a generic finger\n", i );
    elseif finger.type(i) == FT_FMF then
        printf( "Finger %d is a Force Measurement Finger\n", i );
    elseif finger.type(i) == FT_RSI then
        printf( "Finger %d is a Remote Sensor Interface Finger\n", i );
    else 
        printf( "Type of Finger %d is unknown (%d)\n", i, finger.type(i));
    end;
end;
printf( "Done\n" );

