index = 0; -- Finger index of the WSG-DSA-Finger

if dsa.present( index ) then
    printf( "Sending command to WSG-DSA finger %d:\n", index );
    result, response = dsa.cmd( index, 0x60, "Hello" ); -- Issue a LOOP command

    -- Evaluate the response:
    if result == E_SUCCESS then
        printf( "Response (%d bytes): ", #response );
        
        -- Dump received data:
        for i=1,#response do
            printf( "0x%.2X(%c) ", response[i], response[i] );
        end;
        printf( "\n" );
    else
        printf( "Tactile Sensor returned error (%d): %s\n", result, etos( result ));
    end;
else
    printf( "Finger %d is not a WSG-DSA finger\n", index );
end;