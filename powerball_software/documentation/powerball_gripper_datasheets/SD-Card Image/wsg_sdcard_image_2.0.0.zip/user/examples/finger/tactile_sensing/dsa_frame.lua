-- read the sensor information:
cfg = dsa.info( 0 );

-- acquire a single frame:
frame = dsa.getframe( 0 );

-- Print the current frame data:
printf( "Timestamp: %u\n", frame.timestamp );
printf( "Frame data (%dx%d)\n", cfg.cells_x, cfg.cells_y );
for y=0,cfg.cells_y-1 do
    for x=0,cfg.cells_x-1 do
        printf( "%4d ", frame[ x + y * cfg.cells_x + 1 ] );
    end;
    printf( "\n" );
end;
   
   
