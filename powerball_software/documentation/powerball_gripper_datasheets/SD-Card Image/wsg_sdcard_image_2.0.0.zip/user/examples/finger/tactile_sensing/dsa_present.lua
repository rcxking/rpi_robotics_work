for i=0,finger.count()-1 do
    if dsa.present(i) then
        printf( "WSG-DSA available on Finger %d.\n", i );
    end;
end;
