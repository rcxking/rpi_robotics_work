/*
 
 jQuery Tools 1.2.5 Tooltip - UI essentials

 NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.

 http://flowplayer.org/tools/tooltip/

 Since: November 2008
 Date: @DATE 
*/
(function(e){function p(a,b,c){var f=c.relative?a.position().top:a.offset().top,d=c.relative?a.position().left:a.offset().left,g=c.position[0];f-=b.outerHeight()-c.offset[0];d+=a.outerWidth()+c.offset[1];/iPad/i.test(navigator.userAgent)&&(f-=e(window).scrollTop());var j=b.outerHeight()+a.outerHeight();g=="center"&&(f+=j/2);g=="bottom"&&(f+=j);g=c.position[1];a=b.outerWidth()+a.outerWidth();g=="center"&&(d-=a/2);g=="left"&&(d-=a);return{top:f,left:d}}function n(a,b){var c=this,f=a.add(c),d,g=0,j=
0,m=a.attr("title"),q=a.attr("data-tooltip"),r=o[b.effect],l,s=a.is(":input"),n=s&&a.is(":checkbox, :radio, select, :button, :submit"),t=a.attr("type"),k=b.events[t]||b.events[s?n?"widget":"input":"def"];if(!r)throw'Nonexistent effect "'+b.effect+'"';k=k.split(/,\s*/);if(k.length!=2)throw"Tooltip: bad events configuration for "+t;a.bind(k[0],function(a){clearTimeout(g);b.predelay?j=setTimeout(function(){c.show(a)},b.predelay):c.show(a)}).bind(k[1],function(a){clearTimeout(j);b.delay?g=setTimeout(function(){c.hide(a)},
b.delay):c.hide(a)});m&&b.cancelDefault&&(a.removeAttr("title"),a.data("title",m));e.extend(c,{show:function(i){if(!d&&(q?d=e(q):b.tip?d=e(b.tip).eq(0):m?d=e(b.layout).addClass(b.tipClass).appendTo(document.body).hide().append(m):(d=a.next(),d.length||(d=a.parent().next())),!d.length))throw"Cannot find tooltip for "+a;if(c.isShown())return c;d.stop(!0,!0);var h=p(a,d,b);b.tip&&d.html(a.data("title"));i=i||e.Event();i.type="onBeforeShow";f.trigger(i,[h]);if(i.isDefaultPrevented())return c;h=p(a,d,
b);d.css({position:"absolute",top:h.top,left:h.left});l=!0;r[0].call(c,function(){i.type="onShow";l="full";f.trigger(i)});h=b.events.tooltip.split(/,\s*/);d.data("__set")||(d.bind(h[0],function(){clearTimeout(g);clearTimeout(j)}),h[1]&&!a.is("input:not(:checkbox, :radio), textarea")&&d.bind(h[1],function(b){b.relatedTarget!=a[0]&&a.trigger(k[1].split(" ")[0])}),d.data("__set",!0));return c},hide:function(a){if(!d||!c.isShown())return c;a=a||e.Event();a.type="onBeforeHide";f.trigger(a);if(!a.isDefaultPrevented())return l=
!1,o[b.effect][1].call(c,function(){a.type="onHide";f.trigger(a)}),c},isShown:function(a){return a?l=="full":l},getConf:function(){return b},getTip:function(){return d},getTrigger:function(){return a}});e.each("onHide,onBeforeShow,onShow,onBeforeHide".split(","),function(a,d){e.isFunction(b[d])&&e(c).bind(d,b[d]);c[d]=function(a){a&&e(c).bind(d,a);return c}})}e.tools=e.tools||{version:"1.2.5"};e.tools.tooltip={conf:{effect:"toggle",fadeOutSpeed:"fast",predelay:0,delay:30,opacity:1,tip:0,position:["top",
"center"],offset:[0,0],relative:!1,cancelDefault:!0,events:{def:"mouseenter,mouseleave",input:"focus,blur",widget:"focus mouseenter,blur mouseleave",tooltip:"mouseenter,mouseleave"},layout:"<div/>",tipClass:"tooltip"},addEffect:function(a,b,c){o[a]=[b,c]}};var o={toggle:[function(a){var b=this.getConf(),c=this.getTip();b=b.opacity;b<1&&c.css({opacity:b});c.show();a.call()},function(a){this.getTip().hide();a.call()}],fade:[function(a){var b=this.getConf();this.getTip().fadeTo(b.fadeInSpeed,b.opacity,
a)},function(a){this.getTip().fadeOut(this.getConf().fadeOutSpeed,a)}]};e.fn.tooltip=function(a){var b=this.data("tooltip");if(b)return b;a=e.extend(!0,{},e.tools.tooltip.conf,a);if(typeof a.position=="string")a.position=a.position.split(/,?\s/);this.each(function(){b=new n(e(this),a);e(this).data("tooltip",b)});return a.api?b:this}})(jQuery);
