for i=0,finger.count()-1 do
    if finger.state( i, 0x0001 ) then      -- Test for the FINGER ENABLED flag
        printf( "Finger %d is enabled! (state: %.4xh)\n", i, finger.state(i) );    
    else 
        printf( "Finger %d is disabled!\n", i );
    end;
end;

