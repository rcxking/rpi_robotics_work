if finger.type( 1 ) == FT_GENERIC then
   
    -- read the configuration of Finger 1:
    cfg = finger.config( 1 );
   
    -- Print the current finger configuration:
    for key in pairs( cfg ) do
      print( key, cfg[key] );
    end;
   
    -- Add a custom value pair to the configuration:
    cfg["key"] = 1.05;
   
    -- Store the updated configuration to the finger�s nonvolatile memory:
    finger.config( 1, cfg );
else
    printf( "Cannot read the configuration data from a non-generic finger.\n" );
end;