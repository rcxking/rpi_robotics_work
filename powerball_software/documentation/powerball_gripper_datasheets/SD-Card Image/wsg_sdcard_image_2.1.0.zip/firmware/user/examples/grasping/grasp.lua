mc.force( 10 );  -- Set Grasping Force to 10N
-- Grasp a part with a nominal width of 10mm and a speed of 50mm. Max. Clamping travel is 5mm:
while not grasping.grasp( 10, 50, 5 ) do
    printf( "No part grasped – trying again...\n" );
    sleep( 500 );
    grasping.release( 30, 100 );
    sleep( 2000 );
end;
printf( "Part successfully grasped\n" );

