if finger.type(0) == FT_GENERIC then
    printf( "Toggle power of finger 0...\n" );
    for i=1,5 do
        printf( "Step %d of 5\n", i );
        finger.power( 0, true );  -- enable power of finger 0
        sleep( 2000 );
        finger.power( 0, false );  -- disable power of finger 0
        sleep( 2000 );
    end;
    printf( "done!\n" );
else
    printf( "Not a generic finger, cannot change its power state.\n" );
end;
